print("1. Name: Brody Nelson")
print("2. I was on a study abroad program last semester")
print("3. this is my 2nd year at university")
print("4. I am currently living off campus")